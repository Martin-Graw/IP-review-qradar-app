# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

from flask import Blueprint, render_template, current_app, send_from_directory, Response, request
import os
from qpylib import qpylib

# pylint: disable=invalid-name
viewsbp = Blueprint('viewsbp', __name__, url_prefix='/')

# A simple "Hello" endpoint that demonstrates use of render_template
# and qpylib logging.
@viewsbp.route('/')
@viewsbp.route('/<name>')
def hello(name=None):
    qpylib.log('name={0}'.format(name), level='INFO')
    return render_template('hello.html', name=name)

# The presence of this endpoint avoids a Flask error being logged when a browser
# makes a favicon.ico request. It demonstrates use of send_from_directory
# and current_app.
@viewsbp.route('/favicon.ico')
def favicon():
    return send_from_directory(current_app.static_folder, 'favicon-16x16.png')

from ipwhois import IPWhois
from ipwhois.exceptions import IPDefinedError
import json

# This new route will handle WHOIS lookups
@viewsbp.route('/whois/<ip_address>')
def whois_lookup(ip_address):
    try:
        obj = IPWhois(ip_address)
        results = obj.lookup_whois()

        # Format the data to return as JSON
        response_data = {
            'description': results.get('asn_description', 'N/A'),
            'cidr': results.get('asn_cidr', 'N/A'),
            'raw': json.dumps(results, indent=4)
        }
        return current_app.response_class(
            json.dumps(response_data),
            mimetype='application/json'
        )
    except Exception as e:
        qpylib.log(f"WHOIS lookup failed for {ip_address}: {e}", level='ERROR')
        return current_app.response_class(
            json.dumps({'error': 'WHOIS lookup failed'}),
            mimetype='application/json',
            status=500
        )

# This endpoint serves the blocklist for the firewall
@viewsbp.route('/blocklist.txt')
def serve_blocklist():
    # The 'store' directory is located at /opt/app-root/store inside the container
    blocklist_path = os.path.join('/opt/app-root/store', 'blocklist.txt')
    try:
        with open(blocklist_path, 'r') as f:
            content = f.read()
        return Response(content, mimetype='text/plain')
    except FileNotFoundError:
        # If the file doesn't exist for some reason, return an empty list
        return Response('', mimetype='text/plain')

# This endpoint adds a subnet to the blocklist file
@viewsbp.route('/block', methods=['POST'])
def add_to_blocklist():
    # Get the subnet from the JSON data sent by the UI
    data = request.get_json()
    subnet_to_block = data.get('subnet')

    if not subnet_to_block:
        return Response("Missing 'subnet' in request body", status=400)

    # The path to the persistent blocklist file
    blocklist_path = os.path.join('/opt/app-root/store', 'blocklist.txt')

    try:
        # Open the file in append mode ('a') and add the new subnet
        with open(blocklist_path, 'a') as f:
            f.write(subnet_to_block + '\n')
        
        qpylib.log(f"Added subnet to blocklist: {subnet_to_block}", level='INFO')
        return Response(f"Successfully added {subnet_to_block}", mimetype='text/plain')

    except Exception as e:
        qpylib.log(f"Error writing to blocklist.txt: {e}", level='ERROR')
        return Response("Error writing to blocklist file.", status=500)
